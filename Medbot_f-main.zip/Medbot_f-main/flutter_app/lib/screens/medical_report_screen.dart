import 'package:flutter/material.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../widgets/modern_input_card.dart';
import '../auth_service.dart';
import '../login_screen.dart';

class MedicalReportScreen extends StatefulWidget {
  const MedicalReportScreen({super.key});

  @override
  State<MedicalReportScreen> createState() => _MedicalReportScreenState();
}

class ReportHistory {
  final String id;
  final String title;
  final String summary;
  final DateTime date;
  final String type; // 'text', 'image', 'pdf'
  
  ReportHistory({
    required this.id,
    required this.title,
    required this.summary,
    required this.date,
    required this.type,
  });
}

class _MedicalReportScreenState extends State<MedicalReportScreen> {
  final TextEditingController _textController = TextEditingController();
  String _selectedLanguage = 'English';
  Uint8List? _imageBytes;
  File? _selectedPdf;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;
  String _result = '';
  final FlutterTts _flutterTts = FlutterTts();
  bool _isPlaying = false;
  
  // UI State
  String? _userName;
  String? _userEmail;
  
  // Recent history data - will be populated when user analyzes reports
  List<ReportHistory> _recentHistory = [];
  
  // Settings
  bool _notificationsEnabled = true;
  bool _autoSaveReports = true;
  String _defaultLanguage = 'English';

  @override
  void initState() {
    super.initState();
    _initTts();
    _loadUserInfo();
    _textController.addListener(() {
      setState(() {});
    });
  }
  
  Future<void> _loadUserInfo() async {
    final user = FirebaseAuth.instance.currentUser;
    final name = await AuthService.getUserName();
    setState(() {
      _userName = name ?? user?.displayName ?? 'User';
      _userEmail = user?.email ?? 'No email';
    });
  }

  @override
  void dispose() {
    _textController.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  Future<void> _initTts() async {
    await _flutterTts.setVolume(1.0);
    await _flutterTts.setSpeechRate(0.6);
    await _flutterTts.setPitch(1.0);
    
    _flutterTts.setStartHandler(() {
      setState(() => _isPlaying = true);
    });
    
    _flutterTts.setCompletionHandler(() {
      setState(() => _isPlaying = false);
    });
    
    _flutterTts.setErrorHandler((msg) {
      setState(() => _isPlaying = false);
    });
  }

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await image.readAsBytes();
      setState(() {
        _imageBytes = bytes;
        _selectedPdf = null;
        _textController.clear();
      });
    }
  }

  Future<void> _pickPdf() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    
    if (result != null) {
      setState(() {
        _selectedPdf = File(result.files.single.path!);
        _imageBytes = null;
        _textController.clear();
      });
    }
  }

  void _clearAll() {
    setState(() {
      _imageBytes = null;
      _selectedPdf = null;
      _textController.clear();
    });
  }

  Future<void> _analyzeReport() async {
    final inputText = _textController.text.trim();
    
    if (inputText.isEmpty && _imageBytes == null && _selectedPdf == null) {
      _showMessage('Please enter text, select image, or choose PDF', Colors.orange);
      return;
    }
    
    setState(() {
      _isLoading = true;
      _result = '';
    });

    try {
      final apiKey = dotenv.env['GEMINI_API_KEY'];
      if (apiKey == null || apiKey.isEmpty) {
        throw Exception('API key not found');
      }

      final model = GenerativeModel(model: 'gemini-2.5-flash', apiKey: apiKey);
      final content = <Content>[];
      
      if (_imageBytes != null) {
        String imagePrompt = _buildImageAnalysisPrompt();
        content.add(Content.multi([
          TextPart(imagePrompt),
          DataPart('image/jpeg', _imageBytes!)
        ]));
      } else if (_selectedPdf != null) {
        final pdfText = await _extractPdfText(_selectedPdf!);
        content.add(Content.text(_buildAnalysisPrompt(pdfText)));
      } else if (inputText.isNotEmpty) {
        content.add(Content.text(_buildAnalysisPrompt(inputText)));
      }

      final response = await model.generateContent(content);
      final result = response.text ?? 'No analysis available';
      
      setState(() {
        _result = result;
      });
      
      // Add to history
      _addToHistory(result);
      
      _showMessage('Analysis completed!', Colors.green);
      
    } catch (e) {
      _showMessage('Error: ${e.toString()}', Colors.red);
    }

    setState(() {
      _isLoading = false;
    });
  }

  String _buildImageAnalysisPrompt() {
    return '''
    You are an experienced medical assistant. Analyze the attached medical report image and provide a concise summary in $_selectedLanguage.

    Your response must be in plain text only. Use the following structure:

    Condition: briefly identify the primary diagnosis or finding
    Urgency: specify if this is Low, Medium, High, or Critical

    Foods to Eat: list beneficial foods that aid recovery
    Foods to Avoid: list foods that may worsen the condition

    Action: list the key medical recommendations

    Keep the entire response under 300 words dont use emojis, asterisks, hashtags, or any special formatting symbols.
    ''';
  }

  String _buildAnalysisPrompt(String reportText) {
    return '''
    You are an experienced medical assistant. Analyze the medical report text and provide a concise summary in $_selectedLanguage.

    Medical Report Text: $reportText

    Your response must be in plain text only. Use the following structure:

    Condition: briefly identify the primary diagnosis or finding
    Urgency: specify if this is Low, Medium, High, or Critical

    Foods to Eat: list beneficial foods that aid recovery
    Foods to Avoid: list foods that may worsen the condition

    Action: list the key medical recommendations

    Keep the entire response under 300 words dont use emojis, asterisks, hashtags, or any special formatting symbols.
    ''';
  }
  
  Future<String> _extractPdfText(File pdfFile) async {
    try {
      final bytes = await pdfFile.readAsBytes();
      final document = PdfDocument(inputBytes: bytes);
      final text = PdfTextExtractor(document).extractText();
      document.dispose();
      return text;
    } catch (e) {
      throw Exception('Failed to extract PDF text: $e');
    }
  }

  void _showMessage(String message, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Future<void> _logout() async {
    await AuthService.signOut();
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    }
  }

  Future<void> _playTts() async {
    if (_isPlaying) {
      await _flutterTts.stop();
      setState(() => _isPlaying = false);
      _showMessage('Audio stopped', Colors.orange);
      return;
    }
    
    if (_result.isEmpty) {
      _showMessage('No analysis to play', Colors.orange);
      return;
    }
    
    try {
      await _flutterTts.setLanguage('en-US');
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setSpeechRate(0.6);
      
      setState(() => _isPlaying = true);
      
      final result = await _flutterTts.speak(_result);
      
      if (result == 1) {
        _showMessage('🔊 Audio playing', Colors.green);
      } else {
        setState(() => _isPlaying = false);
        _showMessage('Audio failed to start', Colors.red);
      }
      
    } catch (e) {
      setState(() => _isPlaying = false);
      _showMessage('Audio error: ${e.toString()}', Colors.red);
    }
  }

  bool get _hasContent => 
      _textController.text.isNotEmpty || _imageBytes != null || _selectedPdf != null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      drawer: _buildSideDrawer(),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu_rounded),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        title: const Text(
          'MedReport Analyzer',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: GestureDetector(
              onTap: _showUserProfile,
              child: CircleAvatar(
                backgroundColor: Colors.white.withOpacity(0.2),
                child: Text(
                  _userName?.substring(0, 1).toUpperCase() ?? 'U',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  ModernInputCard(
                    controller: _textController,
                    selectedLanguage: _selectedLanguage,
                    imageBytes: _imageBytes,
                    selectedPdf: _selectedPdf,
                    onLanguageChanged: (String? value) {
                      if (value != null) {
                        setState(() {
                          _selectedLanguage = value;
                        });
                      }
                    },
                    onPickImage: _pickImage,
                    onPickPdf: _pickPdf,
                    onClear: _clearAll,
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Results Section
                  if (_result.isNotEmpty) ...[
                    _buildResultsCard(),
                    const SizedBox(height: 100),
                  ],
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: SafeArea(
              child: SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : (_hasContent ? _analyzeReport : null),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1565C0),
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey[300],
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: _isLoading 
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white, 
                              strokeWidth: 2,
                            ),
                          ),
                          SizedBox(width: 12),
                          Text(
                            'Analyzing...', 
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.analytics_rounded,
                            size: 20,
                            color: _hasContent ? Colors.white : Colors.grey[500],
                          ),
                          const SizedBox(width: 12),
                          Text(
                            'Analyze Report',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: _hasContent ? Colors.white : Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultsCard() {
    return Card(
      color: Colors.white,
      elevation: 4,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1565C0).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.analytics_rounded, 
                    color: Color(0xFF1565C0),
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Medical Analysis ($_selectedLanguage)',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold, 
                      fontSize: 18,
                      color: Color(0xFF1565C0),
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Audio Controls
            Row(
              children: [
                Expanded(
                  child: _buildActionChip(
                    icon: _isPlaying ? Icons.stop_rounded : Icons.play_arrow_rounded,
                    label: _isPlaying ? 'Stop Audio' : 'Play Audio',
                    color: _isPlaying ? Colors.red : Colors.green,
                    onPressed: _playTts,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 20),
            
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF5F7FA),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                _result,
                style: const TextStyle(
                  fontSize: 15,
                  height: 1.6,
                  color: Color(0xFF2E3A47),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionChip({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildSideDrawer() {
    return Drawer(
      backgroundColor: Colors.white,
      child: Column(
        children: [
          // Header
          Container(
            height: 200,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 35,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      child: Text(
                        _userName?.substring(0, 1).toUpperCase() ?? 'U',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _userName ?? 'User',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _userEmail ?? '',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          // Menu Items
          Expanded(
            child: Column(
              children: [
                const SizedBox(height: 20),
                
                // Recent History Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Icon(Icons.history_rounded, color: Colors.grey[600], size: 20),
                      const SizedBox(width: 12),
                      Text(
                        'Recent History',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[800],
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // History List
                Expanded(
                  child: _recentHistory.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.history_rounded,
                                size: 48,
                                color: Colors.grey[400],
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'No Recent History',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[600],
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Analyze your first medical report to see it here',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[500],
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        itemCount: _recentHistory.length,
                        itemBuilder: (context, index) {
                          final history = _recentHistory[index];
                          return _buildHistoryItem(history, index);
                        },
                      ),
                ),
                
                // Bottom Actions
                const Divider(),
                
                ListTile(
                  leading: Icon(Icons.settings_rounded, color: Colors.grey[600]),
                  title: Text(
                    'Settings',
                    style: TextStyle(color: Colors.grey[800]),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    _showSettings();
                  },
                ),
                
                ListTile(
                  leading: Icon(Icons.help_outline_rounded, color: Colors.grey[600]),
                  title: Text(
                    'Help & Support',
                    style: TextStyle(color: Colors.grey[800]),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    _showHelp();
                  },
                ),
                
                const SizedBox(height: 20),
                
                // Logout Button
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        _showLogoutDialog();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red[50],
                        foregroundColor: Colors.red[700],
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: Colors.red[200]!),
                        ),
                      ),
                      icon: const Icon(Icons.logout_rounded, size: 20),
                      label: const Text(
                        'Logout',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ),
                
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildHistoryItem(ReportHistory history, int index) {
    IconData typeIcon;
    Color typeColor;
    
    switch (history.type) {
      case 'image':
        typeIcon = Icons.image_rounded;
        typeColor = Colors.green;
        break;
      case 'pdf':
        typeIcon = Icons.picture_as_pdf_rounded;
        typeColor = Colors.red;
        break;
      default:
        typeIcon = Icons.text_snippet_rounded;
        typeColor = Colors.blue;
    }
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            Navigator.pop(context);
            _loadHistoryItem(history);
          },
          onLongPress: () {
            _showDeleteHistoryDialog(history, index);
          },
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey[50],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey[200]!),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: typeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    typeIcon,
                    color: typeColor,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        history.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        history.summary,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _formatDate(history.date),
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date).inDays;
    
    if (difference == 0) {
      return 'Today';
    } else if (difference == 1) {
      return 'Yesterday';
    } else if (difference < 7) {
      return '$difference days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
  
  void _addToHistory(String analysis) {
    final title = _generateReportTitle();
    final summary = _generateSummary(analysis);
    
    final newHistory = ReportHistory(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      summary: summary,
      date: DateTime.now(),
      type: _getAnalysisType(),
    );
    
    setState(() {
      _recentHistory.insert(0, newHistory);
      // Keep only last 10 reports
      if (_recentHistory.length > 10) {
        _recentHistory = _recentHistory.take(10).toList();
      }
    });
  }
  
  String _generateReportTitle() {
    if (_imageBytes != null) {
      return 'Medical Image Analysis';
    } else if (_selectedPdf != null) {
      return 'PDF Report Analysis';
    } else {
      return 'Text Report Analysis';
    }
  }
  
  String _generateSummary(String analysis) {
    final lines = analysis.split('\n').where((line) => line.trim().isNotEmpty).toList();
    if (lines.isNotEmpty) {
      String summary = lines.first.trim();
      if (summary.length > 80) {
        summary = '${summary.substring(0, 80)}...';
      }
      return summary;
    }
    return 'Medical report analysis completed';
  }
  
  String _getAnalysisType() {
    if (_imageBytes != null) return 'image';
    if (_selectedPdf != null) return 'pdf';
    return 'text';
  }
  
  void _loadHistoryItem(ReportHistory history) {
    setState(() {
      _result = 'Previous Analysis from ${_formatDate(history.date)}:\n\n${history.summary}\n\nNote: This is a simplified view. Full analysis details would be stored and retrieved from your database in a production app.';
    });
    
    _showMessage('Loaded: ${history.title}', Colors.green);
  }
  
  void _showDeleteHistoryDialog(ReportHistory history, int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete Report'),
        content: Text('Are you sure you want to delete "${history.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Close drawer
              _deleteHistoryItem(index);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
  
  void _deleteHistoryItem(int index) {
    setState(() {
      _recentHistory.removeAt(index);
    });
    _showMessage('Report deleted', Colors.orange);
  }
  
  void _showUserProfile() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: const Color(0xFF1565C0).withOpacity(0.1),
                child: Text(
                  _userName?.substring(0, 1).toUpperCase() ?? 'U',
                  style: const TextStyle(
                    color: Color(0xFF1565C0),
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              
              const SizedBox(height: 20),
              
              Text(
                _userName ?? 'User',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              
              const SizedBox(height: 8),
              
              Text(
                _userEmail ?? '',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              
              const SizedBox(height: 24),
              
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    _buildProfileInfo('Member Since', 'January 2024'),
                    const Divider(height: 20),
                    _buildProfileInfo('Reports Analyzed', '${_recentHistory.length}'),
                    const Divider(height: 20),
                    _buildProfileInfo('Account Type', 'Premium'),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Close'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _editProfile();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1565C0),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Edit Profile'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildProfileInfo(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
  
  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _logout();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }
  
  void _editProfile() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Edit Profile',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              
              TextField(
                decoration: InputDecoration(
                  labelText: 'Full Name',
                  hintText: _userName,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  prefixIcon: const Icon(Icons.person),
                ),
              ),
              
              const SizedBox(height: 16),
              
              TextField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: _userEmail,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  prefixIcon: const Icon(Icons.email),
                ),
                enabled: false,
              ),
              
              const SizedBox(height: 24),
              
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _showMessage('Profile updated successfully!', Colors.green);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1565C0),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  void _showSettings() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          padding: const EdgeInsets.all(24),
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Settings',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              
              // Notifications
              _buildSettingsTile(
                'Notifications',
                'Receive analysis completion alerts',
                Icons.notifications_rounded,
                Switch(
                  value: _notificationsEnabled,
                  onChanged: (value) {
                    setState(() {
                      _notificationsEnabled = value;
                    });
                  },
                ),
              ),
              
              const Divider(height: 32),
              
              // Auto Save
              _buildSettingsTile(
                'Auto Save Reports',
                'Automatically save analysis to history',
                Icons.save_rounded,
                Switch(
                  value: _autoSaveReports,
                  onChanged: (value) {
                    setState(() {
                      _autoSaveReports = value;
                    });
                  },
                ),
              ),
              
              const Divider(height: 32),
              
              // Default Language
              _buildSettingsTile(
                'Default Language',
                'Set default analysis language',
                Icons.language_rounded,
                DropdownButton<String>(
                  value: _defaultLanguage,
                  underline: const SizedBox(),
                  items: ['English', 'Hindi', 'Telugu'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _defaultLanguage = newValue;
                        _selectedLanguage = newValue;
                      });
                    }
                  },
                ),
              ),
              
              const SizedBox(height: 24),
              
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    _showMessage('Settings saved successfully!', Colors.green);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1565C0),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Save Settings'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildSettingsTile(String title, String subtitle, IconData icon, Widget trailing) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFF1565C0).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: const Color(0xFF1565C0),
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
        trailing,
      ],
    );
  }
  
  void _showHelp() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.help_outline_rounded,
                      color: Colors.blue,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Help & Support',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 20),
              
              _buildHelpItem(
                'How to analyze reports?',
                'Upload an image, PDF, or paste text of your medical report and tap "Analyze Report".',
                Icons.analytics_rounded,
              ),
              
              const SizedBox(height: 16),
              
              _buildHelpItem(
                'Supported formats',
                'We support JPG, PNG images, PDF files, and plain text input.',
                Icons.file_present_rounded,
              ),
              
              const SizedBox(height: 16),
              
              _buildHelpItem(
                'Audio playback',
                'Tap the play button to hear your analysis. Adjust device volume if needed.',
                Icons.volume_up_rounded,
              ),
              
              const SizedBox(height: 16),
              
              _buildHelpItem(
                'Privacy & Security',
                'Your reports are processed securely and not stored on our servers.',
                Icons.security_rounded,
              ),
              
              const SizedBox(height: 24),
              
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        _showMessage('Contact support: support@medreport.com', Colors.blue);
                      },
                      icon: const Icon(Icons.email_rounded, size: 18),
                      label: const Text('Contact Us'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF1565C0),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Got it'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildHelpItem(String title, String description, IconData icon) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(6),
          ),
          child: Icon(
            icon,
            color: Colors.grey[600],
            size: 16,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}