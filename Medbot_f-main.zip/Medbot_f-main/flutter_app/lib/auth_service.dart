import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get current user
  static User? get currentUser => _auth.currentUser;

  // Auth state stream
  static Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Sign up with email and password
  static Future<User?> signUp(String email, String password, {String? name}) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      final user = credential.user;
      if (user != null) {
        // Update display name if provided
        if (name != null && name.isNotEmpty) {
          await user.updateDisplayName(name);
        }
        
        // Store user data in Firestore
        await _firestore.collection('users').doc(user.uid).set({
          'email': email,
          'name': name ?? '',
          'createdAt': FieldValue.serverTimestamp(),
          'lastLoginAt': FieldValue.serverTimestamp(),
        });
      }
      
      return user;
    } catch (e) {
      rethrow;
    }
  }

  // Sign in with email and password
  static Future<User?> signIn(String email, String password) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      final user = credential.user;
      if (user != null) {
        // Update last login time
        await _firestore.collection('users').doc(user.uid).update({
          'lastLoginAt': FieldValue.serverTimestamp(),
        });
      }
      
      return user;
    } catch (e) {
      rethrow;
    }
  }

  // Sign out
  static Future<void> signOut() async {
    await _auth.signOut();
  }

  // Check if user is logged in
  static bool isLoggedIn() {
    return _auth.currentUser != null;
  }

  // Get user email
  static String? getUserEmail() {
    return _auth.currentUser?.email;
  }

  // Get user name
  static Future<String?> getUserName() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    
    // Try to get from display name first
    if (user.displayName != null && user.displayName!.isNotEmpty) {
      return user.displayName;
    }
    
    // Otherwise get from Firestore
    try {
      final doc = await _firestore.collection('users').doc(user.uid).get();
      return doc.data()?['name'] as String?;
    } catch (e) {
      return null;
    }
  }

  // Get user data from Firestore
  static Future<Map<String, dynamic>?> getUserData() async {
    final user = _auth.currentUser;
    if (user == null) return null;
    
    try {
      final doc = await _firestore.collection('users').doc(user.uid).get();
      return doc.data();
    } catch (e) {
      return null;
    }
  }

  // Update user profile
  static Future<void> updateUserProfile({String? name, String? email}) async {
    final user = _auth.currentUser;
    if (user == null) return;
    
    try {
      // Update Firebase Auth profile
      if (name != null) {
        await user.updateDisplayName(name);
      }
      if (email != null) {
        await user.updateEmail(email);
      }
      
      // Update Firestore document
      final updates = <String, dynamic>{};
      if (name != null) updates['name'] = name;
      if (email != null) updates['email'] = email;
      updates['updatedAt'] = FieldValue.serverTimestamp();
      
      await _firestore.collection('users').doc(user.uid).update(updates);
    } catch (e) {
      rethrow;
    }
  }
}