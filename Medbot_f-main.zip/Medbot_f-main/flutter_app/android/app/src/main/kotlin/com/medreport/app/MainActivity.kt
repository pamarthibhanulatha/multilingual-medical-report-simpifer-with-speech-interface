package com.medreport.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
